"use client";

import { useEffect, useRef, useState } from "react";
import useEmblaCarousel from "embla-carousel-react";
import { CloudImage } from "@/components/ui/CloudImage";
import { ChevronRightIcon } from "@/components/ui/icons";
import { testimonials } from "@/lib/testimonials";
import { reveal } from "@/lib/reveal";
import { isBackdropFrozen } from "@/lib/menu-backdrop";
import { cn } from "@/lib/utils";

type EmblaApi = NonNullable<ReturnType<typeof useEmblaCarousel>[1]>;

const AUTOPLAY_MS = 5000; // ek-ta slide-er jonno koto ms (progress bar-o ei somoye egoy)
const GLIDE_DURATION = 42; // embla scroll speed: boro = dhire/narom glide (default 25 ~ 0.9s, 42 ~ 1.6s)

/* Figma: card 302 x 336 (lg+ e 4 ta ekshathe, md-te 3, sm-e 2, gap 24px), nicher progress bar (6 x 110px, gap 9px) + prev/next (32px) */
export function TestimonialCarousel() {
  const [emblaRef, emblaApi] = useEmblaCarousel({ align: "center", loop: true, containScroll: false, duration: GLIDE_DURATION });
  const [canPrev, setCanPrev] = useState(false);
  const [canNext, setCanNext] = useState(true);
  const fills = useRef<(HTMLSpanElement | null)[]>([]);
  const regionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!emblaApi) return;

    /* Progress bar: scroll-er shathe segment gula fill hoy. Direct DOM update, jeno protita frame-e re-render na hoy */
    const updateProgress = (api: EmblaApi) => {
      const active = api.scrollSnapList().length > 1 ? api.selectedScrollSnap() : -1;
      fills.current.forEach((el, i) => {
        if (!el) return;
        el.style.transform = "scaleX(1)";
        el.style.opacity = active === -1 || i === active ? "1" : "0";
      });
    };
    /* Prev arrow: prothom slide-e thakle gray + click kora jay na. 2nd slide-e gele (autoplay ba Next click e) active hoy.
       Embla `loop: true`-te canScrollPrev() shobsomoy true thake, tai selectedScrollSnap() dekhe nijera thik kori.
       Next arrow loop-er jonno shobsomoy active (slide korar moto jinis thakle). */
    const updateButtons = (api: EmblaApi) => {
      const hasSlides = api.scrollSnapList().length > 1;
      setCanPrev(hasSlides && api.selectedScrollSnap() > 0);
      setCanNext(hasSlides && api.canScrollNext());
    };

    /* Autoplay cholle bar-er fill niche-r effect-e time diye hoy. Shudhu reduced-motion-e (autoplay nai) scroll-er shathe fill hoy */
    const scrollDriven = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const onScroll = () => {
      if (scrollDriven) updateProgress(emblaApi);
    };
    const onSelect = () => updateButtons(emblaApi);
    const onReInit = () => {
      if (scrollDriven) updateProgress(emblaApi);
      updateButtons(emblaApi);
    };

    onReInit();
    emblaApi.on("scroll", onScroll).on("select", onSelect).on("reInit", onReInit);
    return () => {
      emblaApi.off("scroll", onScroll).off("select", onSelect).off("reInit", onReInit);
    };
  }, [emblaApi]);

  /* Autoplay (infinite loop): protita slide AUTOPLAY_MS dhore thake, tarpor nijei porer slide-e jay. Shesh slide-er por card gulo seamless-e
     prothom card-e continue kore (embla loop), kothao ferot jay na, reload/restart-er feel nai.
     Progress bar (story / hero-carousel-er standard pattern): ek-ta segment = ek-ta slide. Shudhu active slide-er segment dhire fill hoy
     (AUTOPLAY_MS dhore), baki segment grey. Slide bodlale ager segment fade out hoy, porer-ta 0 theke fill shuru kore. Shesh theke prothome gele
     o ekoi niyom, bar kokhono ekdom khali ba "drain" hoy na. Arrow / drag korle active segment sathe sathe bodle jay ar timer reset hoy.
     Pause hoy: mouse upore thakle, keyboard focus bhitore thakle, drag cholle, section screen-e na thakle, tab hidden hole.
     prefers-reduced-motion-e autoplay hoy na (shudhu active segment solid dekhay). */
  useEffect(() => {
    if (!emblaApi) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const region = regionRef.current;
    let elapsed = 0;
    let activeSeg = -1;
    let last = 0;
    let raf = 0;
    let hovered = false;
    let focused = false;
    let dragging = false;
    let inView = false;

    /* Active segment-er fill = elapsed / AUTOPLAY_MS. Segment inactive hole opacity fade out (scale ta fade shesh howar por-i reset hoy,
       tai ager segment ekdom khali hoye jay na), abar active hole 0 theke shuru */
    const paint = (active: number, progress: number) => {
      fills.current.forEach((el, i) => {
        if (!el) return;
        if (i === active) {
          if (i !== activeSeg) {
            el.style.transition = "none";
            el.style.transform = "scaleX(0)";
            el.style.opacity = "1";
          }
          el.style.transform = `scaleX(${Math.min(1, Math.max(0, progress))})`;
        } else if (i === activeSeg) {
          el.style.transition = "opacity 450ms ease";
          el.style.opacity = "0";
        }
      });
      activeSeg = active;
    };

    const loop = (now: number) => {
      raf = 0;
      const dt = last ? Math.min(now - last, 50) : 16;
      last = now;

      const snaps = emblaApi.scrollSnapList().length;
      if (snaps <= 1) {
        // sob card ekshathe dekha jay, slide korar kichu nai, shob segment bhora
        fills.current.forEach((el) => {
          if (el) {
            el.style.transform = "scaleX(1)";
            el.style.opacity = "1";
          }
        });
        return;
      }

      /* Nav menu (Project / Services) khola thakle autoplay ruke thake: pechone slide/progress bar nore na, tai blur-er niche kono extra frame toiri hoy na */
      const paused = hovered || focused || dragging || document.hidden || isBackdropFrozen();
      if (!paused) elapsed += dt;

      if (elapsed >= AUTOPLAY_MS) {
        elapsed = 0;
        emblaApi.scrollNext(); // loop: shesh slide theke seamless-e prothomey jay
      }

      paint(emblaApi.selectedScrollSnap(), elapsed / AUTOPLAY_MS);

      if (inView) raf = requestAnimationFrame(loop);
    };

    const start = () => {
      if (!raf && inView) {
        last = 0;
        raf = requestAnimationFrame(loop);
      }
    };

    const observer = new IntersectionObserver(
      ([entry]) => {
        inView = entry.isIntersecting;
        if (inView) start();
      },
      { threshold: 0.2 },
    );
    if (region) observer.observe(region);

    const reset = () => {
      elapsed = 0;
    };
    const onDown = () => {
      dragging = true;
    };
    const onUp = () => {
      dragging = false;
      reset();
    };
    const onEnter = () => {
      hovered = true;
    };
    const onLeave = () => {
      hovered = false;
    };
    // mouse click-e button focus pay, oita pause kora jabe na. Shudhu keyboard (focus-visible) hole pause
    const onFocusIn = (e: FocusEvent) => {
      focused = (e.target as HTMLElement).matches(":focus-visible");
    };
    const onFocusOut = () => {
      focused = false;
    };
    const onVisibility = () => {
      if (!document.hidden) start();
    };

    emblaApi.on("select", reset).on("pointerDown", onDown).on("pointerUp", onUp).on("reInit", start);
    const viewport = emblaApi.rootNode(); // shudhu card-er upor hover hole pause, arrow/bar-er upor na
    viewport.addEventListener("pointerenter", onEnter);
    viewport.addEventListener("pointerleave", onLeave);
    region?.addEventListener("focusin", onFocusIn);
    region?.addEventListener("focusout", onFocusOut);
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      observer.disconnect();
      if (raf) cancelAnimationFrame(raf);
      emblaApi.off("select", reset).off("pointerDown", onDown).off("pointerUp", onUp).off("reInit", start);
      viewport.removeEventListener("pointerenter", onEnter);
      viewport.removeEventListener("pointerleave", onLeave);
      region?.removeEventListener("focusin", onFocusIn);
      region?.removeEventListener("focusout", onFocusOut);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [emblaApi]);

  return (
    <div ref={regionRef} className="flex w-full flex-col items-center gap-[1.875rem]" role="region" aria-roledescription="carousel" aria-label="Client testimonials">
      {/* Full-width viewport: majhkhane active card, duipashe porer/ager card-er ongsho peek kore (Figma-r moto) */}
      {/* Reveal ekhane, protita card-e na: embla loop-e left card ashole shesh slide (index 5) hoy, tai card-wise stagger korle
          left card shobar shesh-e (180ms pore) ashto ar faka dekhto. Ekhon 3 ta card ekshathe ek-i animation-e ashe. */}
      <div ref={emblaRef} className="sr-up w-full overflow-hidden" style={reveal(0, { duration: 900, y: 40 })}>
        <ul className="-ml-4 flex md:-ml-[2.8rem]">
          {testimonials.map((t, i) => (
            <li
              key={i}
              role="group"
              aria-roledescription="slide"
              aria-label={`${i + 1} of ${testimonials.length}`}
              className="min-w-0 shrink-0 grow-0 basis-[88%] pl-4 md:basis-[52.6094rem] md:pl-[2.8rem]"
            >
              {/* Figma "Frame 2147237309": 796.95 x 398.47, bg #FAFAFA, radius 24.9, padding 37.36, gap 16.19.
                  li-er basis = card width (796.95) + slide-er gap (2.8rem pl), tai article thik 796.95px hoy (ager basis-e padding-o dhora chhilo, article 752px hoye jachchilo) */}
              <article className="flex h-full flex-col gap-4 rounded-[1.5rem] bg-[#FAFAFA] p-4 sm:p-6 md:min-h-[24.9044rem] md:flex-row md:gap-[1.0119rem] md:rounded-[1.5565rem] md:p-[2.3348rem]">
                {/* Figma "Frame 2147237305": 227.88 x 323.76, white, radius 19.92. Bhitore page-er frame (185.54 wide) charpashe ~21px faka diye boshe,
                    left = (227.88 - 185.54) / 2 = 21.17px (= 9.29%, tai width 81.42% + center), top = 20.8px. Page lomba (185.54 x 852), niche frame-e kete jay (overflow-hidden), radius 8.48 */}
                <div className="relative h-56 shrink-0 overflow-hidden rounded-[1.25rem] bg-white md:h-auto md:w-[14.2425rem] md:self-stretch md:rounded-[1.2452rem]">
                  <div className="absolute left-1/2 top-[1.3rem] w-[81.42%] -translate-x-1/2 overflow-hidden rounded-[0.53rem]">
                    <CloudImage
                      src={t.screenshot}
                      alt={`${t.name}, ${t.role}: website screenshot`}
                      width={0}
                      height={0}
                      sizes="(min-width: 768px) 372px, 80vw"
                      loading="eager" /* lazy hole offscreen/peek card-er image pore load hoy, left card faka dekhay */
                      style={{ width: "100%", height: "auto" }}
                      className="block max-w-none select-none"
                      draggable={false}
                    />
                  </div>
                </div>

                {/* Figma "Frame 2147237303": 478.17 x 319.35, card-er majhe vertically center. Header(71.81) -24.9- quote(128 = 4 line x 32) -54.79- author(39.85) */}
                <div className="flex min-w-0 flex-1 flex-col justify-center gap-5 md:gap-0">
                  <div className="flex flex-col gap-[1.245rem]">
                    <p className="flex items-center gap-[0.6226rem] text-base font-medium leading-[1.2] text-black md:text-xl">
                      <AsteriskIcon className="size-5 shrink-0 text-accent md:size-[1.5563rem]" />
                      {t.duration}
                    </p>
                    <ul className="flex flex-wrap gap-[0.4669rem]">
                      {t.services.map((service) => (
                        <li key={service} className="rounded-full bg-white px-[0.6226rem] py-[0.1556rem] text-sm leading-[1.6] text-black">
                          {service}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* min-h 8rem = 4 line, tai quote 3 line holeo author-er position soman thake */}
                  <blockquote className="text-base leading-[1.6] text-black md:mt-[1.5563rem] md:min-h-[8rem] md:text-xl">{t.quote}</blockquote>

                  <div className="flex items-end justify-between gap-4 md:mt-[3.4244rem]">
                    <div className="flex min-w-0 items-center gap-[0.4669rem]">
                      {t.avatar ? (
                        <span className="relative size-[2.4906rem] shrink-0 overflow-hidden rounded-full bg-[#D9D9D9]">
                          <CloudImage src={t.avatar} alt="" fill sizes="2.5rem" className="object-cover" />
                        </span>
                      ) : (
                        <span aria-hidden="true" className="grid size-[2.4906rem] shrink-0 place-items-center rounded-full bg-[#D9D9D9] text-sm font-medium text-black/70">
                          {t.name.charAt(0)}
                        </span>
                      )}
                      <div className="flex min-w-0 flex-col gap-[0.2337rem]">
                        <p className="truncate text-base font-medium leading-[1.2] text-black">{t.name}</p>
                        <p className="truncate text-xs leading-[1.2] text-black/70">{t.role}</p>
                      </div>
                    </div>
                    {/* Figma: Bricolage Grotesque 19.92px / 120%, star 14.94px #FFD43B, gap 3.74px */}
                    <p
                      className="flex shrink-0 items-center gap-[0.2337rem] text-[1.2452rem] leading-[1.2] text-black"
                      style={{ fontFamily: "var(--font-bricolage), var(--font-clash), ui-sans-serif, system-ui, sans-serif" }}
                    >
                      {t.rating}
                      <StarIcon className="size-[0.9338rem] text-[#FFD43B]" />
                    </p>
                  </div>
                </div>
              </article>
            </li>
          ))}
        </ul>
      </div>

      {/* Controls: card-er width-er moto (797px): progress bar + prev/next. Team-er moto ekoi behaviour */}
      <div className="sr-up flex w-full max-w-[49.8125rem] items-center gap-5 px-4 md:px-0" style={reveal(450, { duration: 900, y: 20 })}>
        <div className="flex flex-1 items-center gap-[0.5625rem]" aria-hidden="true">
          {testimonials.map((_, i) => (
            <span key={i} className="relative h-[3px] flex-1 overflow-hidden rounded-full bg-[#F0F0F0]">
              <span
                ref={(el) => {
                  fills.current[i] = el;
                }}
                className="absolute inset-0 origin-left rounded-full bg-black will-change-transform"
                style={{ transform: "scaleX(0)", opacity: i === 0 ? 1 : 0 }}
              />
            </span>
          ))}
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <button
            type="button"
            onClick={() => emblaApi?.scrollPrev()}
            disabled={!canPrev}
            aria-label="Previous testimonial"
            className={cn(
              "grid size-8 place-items-center rounded-full transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
              canPrev ? "bg-black text-white" : "bg-[#F0F0F0] text-[#112222]",
            )}
          >
            <ChevronRightIcon className="size-4 -scale-x-100" />
          </button>
          <button
            type="button"
            onClick={() => emblaApi?.scrollNext()}
            disabled={!canNext}
            aria-label="Next testimonial"
            className={cn(
              "grid size-8 place-items-center rounded-full transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
              canNext ? "bg-black text-white" : "bg-[#F0F0F0] text-[#112222]",
            )}
          >
            <ChevronRightIcon className="size-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

/* Figma: 25 x 25 asterisk, fill #0B76F3 (= text-accent). Figma export-er 4-ta path (lomba + ara + dui tirjok), clip-path gulo puro size-er, tai bad. */
function AsteriskIcon({ className }: { className?: string }) {
  return (
    <svg className={className} width="25" height="25" viewBox="0 0 25 25" fill="currentColor" aria-hidden="true">
      <path d="M10.2591 0H14.654L13.3223 6.22614V12.4523V18.6784L14.654 24.9045H10.2591L11.5908 18.6784V12.4523V6.22614L10.2591 0Z" />
      <path d="M-6.0843e-05 14.6488L-6.10352e-05 10.2539L6.22607 11.5857H12.4522H18.6783L24.9045 10.2539V14.6488L18.6783 13.3171H12.4522H6.22607L-6.0843e-05 14.6488Z" />
      <path d="M5.20344 22.8116L2.09576 19.7039L7.44003 16.2431L11.8426 11.8405L16.2452 7.43801L19.706 2.09375L22.8136 5.20143L17.4693 8.66224L13.0668 13.0648L8.66427 17.4674L5.20344 22.8116Z" />
      <path d="M22.8136 19.7039L19.706 22.8116L16.2452 17.4673L11.8426 13.0648L7.44003 8.66225L2.09576 5.20143L5.20344 2.09375L8.66427 7.43802L13.0668 11.8406L17.4693 16.243L22.8136 19.7039Z" />
    </svg>
  );
}

function StarIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M12 2.2l2.9 6.2 6.8.8-5 4.7 1.3 6.7L12 17.2 6 20.6l1.3-6.7-5-4.7 6.8-.8L12 2.2z" />
    </svg>
  );
}