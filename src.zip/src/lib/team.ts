import type { CSSProperties } from "react";
import { images } from "@/lib/images";

export type TeamMember = {
  name: string;
  role: string;
  image: string; // Cloudinary public ID (version shoho)
  imageStyle: CSSProperties; // Figma-r image size/position (card-er bhitore)
  imagePosition?: string; // object-position (shudhu fill/cover framing-e kaje lage). Default center
  captionLow?: boolean; // optional: caption-er bottom padding 12px (default 20px, Figma-r shob card-e 20px)
  linkedin: string;
};

/* Figma-r exact framing: image-er width, height, top (px, 302 x 336 card-er bhitore) ar dx = image-er center card-er center theke koto px dane (+) / bame (-).
   Figma-te protita image-er `left` alada (center kora na), tai card-er center theke dx diye rakhi: left = 50% + dx, translateX(-50%).
   Card Figma-r 302px-er cheye choto/boro hole image-er center card-er shathe thake, width = max(100%, designW) tai kono dike faka thake na.
   dx = (figmaLeft + width / 2) - 151 */
const frame = (width: number, height: number, top: number, dx = 0): CSSProperties => ({
  left: `calc(50% + ${dx}px)`,
  top: `${top / 16}rem`,
  width: `max(100%, ${width / 16}rem)`,
  aspectRatio: `${width} / ${height}`,
  transform: "translateX(-50%)",
});

/* Card-ke puro bhore (cover). Figma framing dewa nai emon image-er jonno: image-er ratio jai hok kono faka thake na, matha (top) dekha jay */
const fill: CSSProperties = { left: 0, top: 0, width: "100%", height: "100%" };

/* Protita image-er Figma CSS (card: 302 x 336):
   1: 375 x 365, left -33, top -0.47        2: 322 x 316, left -17, top 22
   3: 344 x 351, left -16, top -8.47        4: frame left -17 top -4 + image 366 x 319 left -15 top 26.53 (= left -32, top 22.53) */
const framing1 = frame(375, 365, -0.47, 3.5); // (-33 + 187.5) - 151
const framing2 = frame(322, 316, 22, -7); // (-17 + 161) - 151
const framing3 = frame(344, 351, -8.47, 5); // (-16 + 172) - 151
const framing4 = frame(366, 319, 22.53, 0); // (-32 + 183) - 151

/* TODO: LinkedIn profile URL gula boshao ("#" placeholder).
   5 ar 6 number-er Figma CSS dewa hoy nai, tai ekhon card bhore (cover, matha upore) dekhay. CSS dile exact framing boshiye dibo. */
export const team: TeamMember[] = [
  { name: "Mahamudul Islam", role: "CEO at Prographr", image: images.teamMember1, imageStyle: framing1, linkedin: "#" },
  { name: "Neaz Morshed", role: "Web App Developer", image: images.teamMember2, imageStyle: framing2, linkedin: "#" },
  { name: "Raihan Uddin", role: "Sr. Graphic Designer", image: images.teamMember3, imageStyle: framing3, linkedin: "#" },
  { name: "Kawsar Ahmed", role: "UI UX Designer", image: images.teamMember4, imageStyle: framing4, linkedin: "#" },
  { name: "Nahid Hasan", role: "Graphic Designer", image: images.teamMember5, imageStyle: fill, imagePosition: "center top", linkedin: "#" },
  { name: "Ali Hasan Sagor", role: "Presentation Designer", image: images.teamMember6, imageStyle: fill, imagePosition: "center top", linkedin: "#" },
];